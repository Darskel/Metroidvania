var searchData=
[
  ['gameover',['gameover',['../sdl__fonctions_8c.html#a1912ff18815e32e97a54cbad8066c7bc',1,'gameover(SDL_Window *fenetre, SDL_Renderer *renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#a1912ff18815e32e97a54cbad8066c7bc',1,'gameover(SDL_Window *fenetre, SDL_Renderer *renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c']]]
];
