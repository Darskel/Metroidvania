var searchData=
[
  ['jeu',['jeu',['../sdl__fonctions_8c.html#a6b26e56066f868312bf10a531452dd79',1,'jeu(SDL_Window *fenetre, SDL_Renderer **renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#a6b26e56066f868312bf10a531452dd79',1,'jeu(SDL_Window *fenetre, SDL_Renderer **renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c']]],
  ['jpcd',['jpCd',['../structpersonnage__s.html#a05d061a818efa6b7bfa5b3c76ba3b8dd',1,'personnage_s::jpCd()'],['../structs_8h.html#aa2326924fc935f7a3415c0e3894e2ddc',1,'JPCD():&#160;structs.h']]],
  ['jumping',['JUMPING',['../structs_8h.html#ac652084689fae43c9ede5782aedc0d2cab8cd32180a1d5897df8369b127256ad1',1,'structs.h']]]
];
