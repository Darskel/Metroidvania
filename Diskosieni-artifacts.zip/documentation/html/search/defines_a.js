var searchData=
[
  ['offsethitboxh',['OFFSETHITBOXH',['../structs_8h.html#a255df5df578ec4f5a3cc1a10d2ba90f6',1,'structs.h']]],
  ['offsethitboxr',['OFFSETHITBOXR',['../structs_8h.html#a6dcb8420dba97d657875e47d243f5306',1,'structs.h']]]
];
