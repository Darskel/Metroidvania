var searchData=
[
  ['coeurdroprate',['COEURDROPRATE',['../structs_8h.html#a5c69a254991c8be73f994c57220f1673',1,'structs.h']]]
];
