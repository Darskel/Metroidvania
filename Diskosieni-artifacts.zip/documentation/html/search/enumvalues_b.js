var searchData=
[
  ['true',['TRUE',['../structs_8h.html#a74dcbee810ba5df4945e9b7c5f92e2e9aa82764c3079aea4e60c80e45befbb839',1,'structs.h']]]
];
