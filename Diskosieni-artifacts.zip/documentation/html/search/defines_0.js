var searchData=
[
  ['animdelaymenu',['ANIMDELAYMENU',['../structs_8h.html#a7c2efea2ebf5c931359388126361cc97',1,'structs.h']]]
];
