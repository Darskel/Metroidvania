var searchData=
[
  ['vitattackpers',['VITATTACKPERS',['../structs_8h.html#ae61089395a1490a8242e41d55b720357',1,'structs.h']]],
  ['vitchutepers',['VITCHUTEPERS',['../structs_8h.html#a51fffba4988e62b540adbeb5ce5d0993',1,'structs.h']]],
  ['vitdeppers',['VITDEPPERS',['../structs_8h.html#a52280fbbe28eda3540ba23e3fc3195e2',1,'structs.h']]],
  ['vitsautpers',['VITSAUTPERS',['../structs_8h.html#a246757ac96450448d775864c3f543e03',1,'structs.h']]],
  ['volumeboxsize',['VOLUMEBOXSIZE',['../structs_8h.html#ad413eeeadfc5d9621c71cc52075c1550',1,'structs.h']]],
  ['volumetime',['VOLUMETIME',['../structs_8h.html#aa0d0f8a2c7c78ac4381a5ea26487ac5b',1,'structs.h']]]
];
