var searchData=
[
  ['fontsize',['FONTSIZE',['../structs_8h.html#a5d52eeb41a03aeda6974d60772531f96',1,'structs.h']]],
  ['framedelay',['FRAMEDELAY',['../structs_8h.html#abd4b5f839f90f855c5f289c24667eea5',1,'structs.h']]],
  ['freqclign',['FREQCLIGN',['../structs_8h.html#af852ef65e0bf9575c401e7e695fdecdd',1,'structs.h']]]
];
