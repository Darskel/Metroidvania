var searchData=
[
  ['idle',['IDLE',['../structs_8h.html#ac652084689fae43c9ede5782aedc0d2cafd6a0e4343048b10646dd2976cc5ad18',1,'structs.h']]]
];
