var searchData=
[
  ['attacking',['ATTACKING',['../structs_8h.html#ac652084689fae43c9ede5782aedc0d2ca05f520974a8946a4b11907b698557a8b',1,'structs.h']]]
];
