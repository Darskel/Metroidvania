var searchData=
[
  ['jumping',['JUMPING',['../structs_8h.html#ac652084689fae43c9ede5782aedc0d2cab8cd32180a1d5897df8369b127256ad1',1,'structs.h']]]
];
