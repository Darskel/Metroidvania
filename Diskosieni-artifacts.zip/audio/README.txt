ALL THE MUSICS FROM THIS FOLDER ARE IN THE PUBLIC DOMAIN.

Link for :

Begin.wav - The Adventure Begins. by Frenchyboy Studios : https://opengameart.org/content/the-adventure-begins
Futuristic.wav - Mysterious, Futuristic 8 - bit Music Loop by Frenchyboy : https://opengameart.org/content/mysterious-futuristic-8-bit-music-loop
EndlessPain.wav - Endless Pain of Nightmares by nene : https://opengameart.org/content/endless-pain-of-nightmares
Mysterious.wav - Mysterious by nene : https://opengameart.org/content/mysterious
LongAway.wav - Long Away Home [8bit] by nene : https://opengameart.org/content/long-away-home-8bit
Pulsar.wav - Pulsar [Famitracker 2A03] by celestialghost8 : https://opengameart.org/content/pulsar-famitracker-2a03
Arc.wav - swing2 by artisticdude : https://opengameart.org/content/rpg-sound-pack
Singe.wav - mnstr5 by artisticdude : https://opengameart.org/content/rpg-sound-pack
Vifplume.wav - shade5 by artisticdude : https://opengameart.org/content/rpg-sound-pack
Serpent.wav - slime10 by artisticdude : https://opengameart.org/content/rpg-sound-pack
Door.wav - metal_interaction1 by qubodup : https://opengameart.org/content/metal-interactions
Murglace.wav - freeze by artisticdude : https://opengameart.org/content/freeze-spell-0
Item.wav - power_up_02.ogg by rubberduck : https://opengameart.org/content/50-cc0-retro-synth-sfx
Touche.wav - swish_4 by artisticdude (submitted by Ogrebane) : https://opengameart.org/content/battle-sound-effects
Menu.wav - misc_menu_4.wav by Lekif : https://opengameart.org/content/gui-sound-effects