var searchData=
[
  ['vit_5fatt',['vit_att',['../structpersonnage__s.html#a0022973bab638a02774a19710cedcd17',1,'personnage_s::vit_att()'],['../structtype__monstre__s.html#a5bb66d5b722fc97f901c5eaf7d621fd4',1,'type_monstre_s::vit_att()']]],
  ['vit_5fchute',['vit_chute',['../structpersonnage__s.html#a8e340f828bfffa2c47269e315609ed01',1,'personnage_s']]],
  ['vit_5fdep',['vit_dep',['../structpersonnage__s.html#a6899a0efdc3a3fccb060aaf06b4e4b8d',1,'personnage_s::vit_dep()'],['../structtype__monstre__s.html#a768470695da3d9377f1e7e97a3c45ed7',1,'type_monstre_s::vit_dep()']]],
  ['vit_5fsaut',['vit_saut',['../structpersonnage__s.html#abf199b160e1ce327b7def1ed1ee00b39',1,'personnage_s']]],
  ['vitanim',['vitAnim',['../structpersonnage__s.html#af44ce58e7c6ca78f9ceff803bb8bb931',1,'personnage_s']]],
  ['vitesseanim',['vitesseAnim',['../structtype__monstre__s.html#a125257fd616cb7a0a4c82ae30f7d849e',1,'type_monstre_s']]]
];
