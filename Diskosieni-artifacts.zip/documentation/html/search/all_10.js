var searchData=
[
  ['quitter_5fsdl',['quitter_SDL',['../sdl__fonctions_8c.html#af4ffdd61eb400c65a78258ee8ad1172a',1,'quitter_SDL(SDL_Window **fenetre, SDL_Renderer **renderer):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#af4ffdd61eb400c65a78258ee8ad1172a',1,'quitter_SDL(SDL_Window **fenetre, SDL_Renderer **renderer):&#160;sdl_fonctions.c']]]
];
