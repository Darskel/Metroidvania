var searchData=
[
  ['unavailable',['UNAVAILABLE',['../structs_8h.html#a2bfd39097e1c768d485310d850b99457a3fde93396dcd04d746a8cd3b6b5914bb',1,'structs.h']]]
];
