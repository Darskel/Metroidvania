var searchData=
[
  ['defaultvolume',['DEFAULTVOLUME',['../structs_8h.html#a7acbecd3c32fb1305b543d53d2f7a9cc',1,'structs.h']]]
];
