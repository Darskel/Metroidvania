var searchData=
[
  ['jeu',['jeu',['../sdl__fonctions_8c.html#a6b26e56066f868312bf10a531452dd79',1,'jeu(SDL_Window *fenetre, SDL_Renderer **renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#a6b26e56066f868312bf10a531452dd79',1,'jeu(SDL_Window *fenetre, SDL_Renderer **renderer, SDL_DisplayMode mode, SDL_Joystick *pJoystick, int fullscreen):&#160;sdl_fonctions.c']]]
];
