var searchData=
[
  ['togglepausemusique',['togglePauseMusique',['../sdl__fonctions_8c.html#ae9958e5153c984bfd82ddf91f87e477e',1,'togglePauseMusique(void):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#ae9958e5153c984bfd82ddf91f87e477e',1,'togglePauseMusique(void):&#160;sdl_fonctions.c']]],
  ['touchesmenu',['TouchesMenu',['../sdl__fonctions_8c.html#a59b9e7efa825b397eac099f072462065',1,'TouchesMenu(int direction, SDL_Point souris, boolean_t bougeSouris, menu_t *menu):&#160;sdl_fonctions.c'],['../sdl__fonctions_8h.html#a59b9e7efa825b397eac099f072462065',1,'TouchesMenu(int direction, SDL_Point souris, boolean_t bougeSouris, menu_t *menu):&#160;sdl_fonctions.c']]],
  ['transformation',['transformation',['../comportement_8c.html#aa96ae07feaec485735be46f76f593026',1,'transformation(personnage_t *p, salle_t *s):&#160;comportement.c'],['../comportement_8h.html#aa96ae07feaec485735be46f76f593026',1,'transformation(personnage_t *p, salle_t *s):&#160;comportement.c']]]
];
