var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvxyz",
  1: "belmpst",
  2: "clst",
  3: "abcdeghijklmnopqstv",
  4: "abcdefhijklmnprstuvxy",
  5: "bei",
  6: "acdfhijmprstuv",
  7: "acdfhijklnoprtvz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Valeurs énumérées",
  7: "Macros"
};

