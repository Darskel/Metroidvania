ALL THE FONTS FROM THIS FOLDER ARE IN THE PUBLIC DOMAIN.

Link for :

BitCasual.ttf - BitCasual by geoff : http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=353
PixelMordred.ttf - PixelMordred by Extant : http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=735