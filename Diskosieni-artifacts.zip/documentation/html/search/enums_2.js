var searchData=
[
  ['ident_5fe',['idEnt_e',['../structs_8h.html#a92c2c7c38ee9d924447e622fff8800c5',1,'structs.h']]],
  ['idsounds_5fe',['idSounds_e',['../structs_8h.html#a26099d1d9a1ef474190622be823aa76c',1,'structs.h']]]
];
